import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Step 1: Load the data
df = pd.read_csv(r"C:\Users\shame\Downloads\imdb analysis\IMDB-Movie-Data.csv")
print("Initial Data Loaded")
print(df.head())

# Step 2: Clean column names
df.columns = df.columns.str.strip()

# Step 3: Handle missing values
df["Revenue (Millions)"] = df["Revenue (Millions)"].fillna(df["Revenue (Millions)"].median())
df["Metascore"] = df["Metascore"].fillna(df["Metascore"].median())

# Step 4: Convert Genre from string to list
df["Genre"] = df["Genre"].str.split(',')

# Step 5: Explode Genre to analyze individual genres
df_genres = df.explode("Genre")
df_genres["Genre"] = df_genres["Genre"].str.strip()

# Step 6: Save cleaned dataset
df.to_csv("Clean_IMDB_Data.csv", index=False)
print("Cleaned data saved to Clean_IMDB_Data.csv")

# Step 7: Exploratory Data Analysis (EDA)

# 7.1 Movies by Year
plt.figure(figsize=(10, 5))
sns.countplot(data=df, x="Year")
plt.title("Number of Movies Released Each Year")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("movies_by_year.png")
plt.show()

# 7.2 Average Rating by Genre
plt.figure(figsize=(12, 6))
sns.barplot(data=df_genres, x="Genre", y="Rating", estimator="mean", errorbar=None)
plt.title("Average IMDb Rating by Genre")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("avg_rating_by_genre.png")
plt.show()

# 7.3 Revenue vs Rating
plt.figure(figsize=(8, 6))
sns.scatterplot(data=df, x="Rating", y="Revenue (Millions)", hue="Year", palette="coolwarm")
plt.title("Revenue vs IMDb Rating")
plt.tight_layout()
plt.savefig("revenue_vs_rating.png")
plt.show()

# 7.4 Top 10 Directors by Average Rating
top_directors = df.groupby("Director")["Rating"].mean().sort_values(ascending=False).head(10)
plt.figure(figsize=(10, 6))
sns.barplot(x=top_directors.values, y=top_directors.index, palette="viridis")
plt.title("Top 10 Directors by Average IMDb Rating")
plt.xlabel("Average IMDb Rating")
plt.tight_layout()
plt.savefig("top_directors.png")
plt.show()

print("EDA Completed. Charts saved as PNG files.")
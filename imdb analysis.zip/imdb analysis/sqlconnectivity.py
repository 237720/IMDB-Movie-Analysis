import pandas as pd
import mysql.connector

# Load CSV data
df = pd.read_csv(r"C:\Users\shame\Downloads\imdb analysis\Clean_IMDB_Data.csv")

# Connect to MySQL
conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='root',
    database='imdb_analysis'
)
cursor = conn.cursor()

# Create the table
cursor.execute("""
CREATE TABLE IF NOT EXISTS imdb_movies (
    Rank INT,
    Title VARCHAR(255),
    Genre TEXT,
    Description TEXT,
    Director VARCHAR(255),
    Actors TEXT,
    Year INT,
    `Runtime (Minutes)` INT,
    Rating FLOAT,
    Votes INT,
    `Revenue (Millions)` FLOAT,
    Metascore INT
)
""")

# Insert rows into the table
for _, row in df.iterrows():
    cursor.execute("""
        INSERT INTO imdb_movies (
            Rank, Title, Genre, Description, Director,
            Actors, Year, `Runtime (Minutes)`, Rating, Votes,
            `Revenue (Millions)`, Metascore
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """, (
        row['Rank'], row['Title'], row['Genre'], row['Description'], row['Director'],
        row['Actors'], row['Year'], row['Runtime (Minutes)'], row['Rating'],
        row['Votes'], row['Revenue (Millions)'], row['Metascore']
    ))

# Commit and close connection
conn.commit()
cursor.close()
conn.close()

print("✅ Data successfully loaded into MySQL table 'imdb_movies'")